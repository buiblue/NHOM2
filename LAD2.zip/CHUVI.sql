DECLARE @chieudai int, @chieurong int, @chuvi int, @dientich int
SET @chieudai=5
SET @chieurong=6
SET @chuvi = (@chieudai+@chieurong)*2

SELECT 'Chu vi'= @chuvi