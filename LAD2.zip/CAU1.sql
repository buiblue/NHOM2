use QLDA
go

declare @LuongNVcaonhat table(
	TenNVluongcaonhat nvarchar(40),
	Luong float
)
insert into @LuongNVcaonhat
	select CONCAT_WS(' ',HONV,TENLOT,TENNV), LUONG from NHANVIEN
	where LUONG = (select MAX(LUONG) FROM NHANVIEN )
	
	select * from @LuongNVcaonhat