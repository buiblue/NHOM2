use QLDA
go

declare @LuongNVTB table(
	TenNVluongtrenTB nvarchar(40),
	Luong float
)
insert into @LuongNVTB
	select CONCAT_WS(' ',HONV,TENLOT,TENNV), LUONG from NHANVIEN
	where LUONG > (select avg (LUONG) from NHANVIEN where PHG=5)
	select * from @LuongNVTB