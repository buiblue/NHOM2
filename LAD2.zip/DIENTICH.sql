﻿DECLARE @chieudai int, @chieurong int, @chuvi int, @dientich int
SET @chieudai=5
SET @chieurong=6
SET @dientich = @chieudai*@chieurong

SELECT  'Diện tích' = @dientich